let numbers = [1,2,3,4,5,6,7,8,9];

// Load the page
function loadPage(){  
  let str = '<ul id="list">'
  const myName = "Stalin Vimal Raj L";
 
  numbers.forEach(function(number) {
    str += '<li><span>'+ number + '</span></li>';
  });
 
  str += '</ul>';
  document.getElementById("numberedCards").innerHTML = str;
  document.getElementById("myName").innerHTML = myName;
}

// Shuffle the numbers
function shuffle(){
  numbers = numbers.sort(() => Math.random() - 0.5);
  loadPage();
}

// Sort the numbers
function sort(){
  numbers = numbers.sort();
  loadPage();    
}